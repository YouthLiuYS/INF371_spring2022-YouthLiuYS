def convert():
    celcius=input("celcius:")
    print("fahrenheit:")
    print(float((celcius))*1.8+32)
def main():
   convert()
if __name__=='__main__':
    main()