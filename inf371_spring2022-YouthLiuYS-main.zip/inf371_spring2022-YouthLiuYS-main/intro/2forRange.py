import random
list=[]
for item in range(0,10):
    list.append(item)
    pass
print(list)
