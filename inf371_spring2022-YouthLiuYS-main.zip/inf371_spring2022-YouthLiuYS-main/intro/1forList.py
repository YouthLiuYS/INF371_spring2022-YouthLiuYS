list=["I finish the for loop"]
for key in list:
    if key:
     print(key)
    pass