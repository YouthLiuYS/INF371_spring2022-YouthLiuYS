from operator import truediv


isRunning=True
while(isRunning):
    word=input("Do you want to quit or not?")
    if(word=="q" or word=="Q"):
        isRunning=False
#This is the program

