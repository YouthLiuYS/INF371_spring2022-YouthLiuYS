# Personal Project: Aircraft war Game Design and Development

1. Objects in the game:
Player's aircraft, enemy aircraft, bullets from player's aircraft, bullets from enemy aircraft
2. functions in the game:  
  2.1 Our aircraft moves through the game user's buttons [WSAD]  and fire bullets by the Space bar.
  2.2 Enemy aircraft moves and fires bullets randomly and automatically [using random functions]  
  2.3 Both aircrafts can fire bullets  
3. Steps to develop the game:
