# INF371: Digital Game Design and Development

Please edit this file to add your personal information
1. Name you are registered with: YouthLiuYS
2. Name you prefer to be called: Yangsen
3. Pronouns: He
